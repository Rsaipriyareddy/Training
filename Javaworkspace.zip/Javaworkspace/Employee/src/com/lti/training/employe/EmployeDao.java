package com.lti.training.employe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.training.employe.DataAccessException;


public class EmployeDao {
	public List<Emp> fetchProducts(String  num) throws DataAccessException {
	int no=Integer.parseInt(num);
	Connection conn=null;
	ResultSet rs=null;
   PreparedStatement stmt=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="hr";
		String pass="hr";
		conn=DriverManager.getConnection(url, user, pass);
		String sql="select * from emp where empno=?";
				
		stmt=conn.prepareStatement(sql);
		stmt.setInt(1, no);
		rs=stmt.executeQuery();
		
		List<Emp> employe=new ArrayList<Emp>();
		while(rs.next()) {
			Emp e=new Emp();
			e.setEmpno(rs.getInt(1));
			e.setEname(rs.getString(2));
			e.setJob(rs.getString(3));
			e.setMgr(rs.getString(4));
			e.setHiredate(rs.getString(5));
			e.setSal(rs.getInt(6));
			e.setComm(rs.getInt(7));
			e.setDeptno(rs.getInt(8));
			employe.add(e);
		}
				return employe;
	
		

}
	catch(ClassNotFoundException e) {
		throw new DataAccessException("unable to load JDBC driver");
	}
	catch(SQLException e) {
		throw new DataAccessException("problem while fetching products from DB",e);
	}
	
	
	
	
	  finally
      {
   	   try {
   		   conn.close();
   	   }
   	   catch(Exception e){
   		   
   		   
   	   }
      }
	}
}
