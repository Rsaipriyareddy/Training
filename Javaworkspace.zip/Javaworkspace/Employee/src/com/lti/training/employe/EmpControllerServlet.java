package com.lti.training.employe;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.training.model.Product;

/**
 * Servlet implementation class EmpControllerServlet
 */
@WebServlet("/EmpControllerServlet")
public class EmpControllerServlet extends HttpServlet {
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String num=request.getParameter("num");
			
			EmployeDao dao=new EmployeDao();
			List<Emp> empp=	dao.fetchProducts(num);
	}

}
