package com.lti.training.employee;


import com.lti.training.employe.DataAccessException;
import com.lti.training.employe.model.Employee;
import com.lti.training.employee.dao.EmployeeDao;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeDao employeeDao= new EmployeeDao();
		Employee employee= new Employee();
		int empno;
		empno=Integer.parseInt(request.getParameter("empno"));
	
	try {
		
		employee= employeeDao.fetchEmployee(empno);
		HttpSession session= request.getSession();
		
		session.setAttribute("Employee", employee);
		
		response.sendRedirect("viewEmployee.jsp");
		
	} catch (DataAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
