package com.lti.training.employee.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.lti.training.employe.DataAccessException;
import com.lti.training.employe.model.Employee;

public class EmployeeDao {
	public Employee fetchEmployee(int empno) throws DataAccessException{
		Connection conn = null; //manages the connection between the app and database
		PreparedStatement stmt = null;//helps us to execute SQL statements
		ResultSet rs =  null;//helps us to fetch the result of a select query 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");	//Load the Driver(Strp-I)
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "hr", "hr");//Creating Connection
																																								
			
			String sql = "select * from emp where empno=?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, empno);
			
			rs = stmt.executeQuery();
			rs.next();
			/*List<Employee> product = new ArrayList<Employee>();
			
			while(rs.next()) {//for each row
*/				Employee e = new Employee();
				e.setEmpno(rs.getInt(1));
				e.setEname(rs.getString(2));
				e.setJob(rs.getString(3));
				e.setMgr(rs.getInt(4));
				e.setHiredate(rs.getDate(5).toString());
				e.setSalary(rs.getDouble(6));
				e.setComm(rs.getDouble(7));
				e.setDeptno(rs.getInt(8));
				
				/*product.add(e);
			}*/
			return e;
	}
	catch(ClassNotFoundException e) {
		throw new DataAccessException("Unable to load the JDBC Driver");
	}
	catch(SQLException e) {
		throw new DataAccessException("Problem while fetching product from db");
	}
		
	finally{
			try { conn.close(); }  catch(Exception e) {  e.printStackTrace(); }
		}
	}	
}
