package com.lti.training.employee.exception;

public class DataAccessException extends Exception {
	public DataAccessException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DataAccessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super();
		// TODO Auto-generated constructor stub
	}

	public DataAccessException(String message, Throwable cause) {
		super();
		// TODO Auto-generated constructor stub
	}

	public DataAccessException(String message) {
		super();
		// TODO Auto-generated constructor stub
	}

	public DataAccessException(Throwable cause) {
		super();
		// TODO Auto-generated constructor stub
	}
}
