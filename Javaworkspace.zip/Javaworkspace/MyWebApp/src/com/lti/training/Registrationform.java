package com.lti.training;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.manager.DatabaseUserManager;

/**
 * Servlet implementation class Registrationform
 */
@WebServlet("/register.lti")
public class Registrationform extends HttpServlet {
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        

		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String city=request.getParameter("city");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		DbUserManager mgr= new DbUserManager();
		
		
	 mgr.isValidUser(name,email,city,username,password);
		
			String usernameEncode = Base64.getEncoder().encodeToString(username.getBytes()); 
			 
			String passwordEncode = Base64.getEncoder().encodeToString(password.getBytes()); 
			
			Cookie c1=new Cookie("tom",usernameEncode);
			Cookie c2=new Cookie("jerry",passwordEncode);
			c1.setMaxAge(60*60);
			c2.setMaxAge(60*60);
			response.addCookie(c1);
			response.addCookie(c2);;
			
		
	
		response.sendRedirect("welcome.html");
		
}
	
	}

