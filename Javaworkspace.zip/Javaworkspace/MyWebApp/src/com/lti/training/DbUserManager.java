package com.lti.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//public class DatabaseUserManager {

public class DbUserManager {

	public void isValidUser(String name,String email,String city,String username, String password) {
		Connection conn = null; // manages the connection between the app and db
		PreparedStatement stmt = null; // helps us to execute SQL statements
		ResultSet rs = null;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "hr", "hr");
			String sql="insert into reg1 values(?,?,?,?,?)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, name);
			stmt.setString(2,email);
			stmt.setString(3, city);
			stmt.setString(4, username);
			stmt.setString(5, password);
			 int newrow=stmt.executeUpdate();

			
		} catch (ClassNotFoundException e) {
			
			System.out.println("JDBC driver not found");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

	}
}
