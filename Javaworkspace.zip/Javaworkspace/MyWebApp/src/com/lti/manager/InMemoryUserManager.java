package com.lti.manager;

import java.util.ArrayList;
import java.util.List;

public class InMemoryUserManager {

	private List<User> lu;

	public InMemoryUserManager() {
		// TODO Auto-generated constructor stub
		lu = new ArrayList<User>();
		lu.add(new User("Stefan", "111", true));
		lu.add(new User("Damon", "222", true));
		lu.add(new User("hgugu", "231", false));

	}

	public boolean isValid(String username, String password) {

		for (User us : lu) {
			String name = username;
			if (name.equals(us.getUsername()))
				if (password.equals(us.getPassword()) && us.isActive())
					return true;

		}
		return false;

	}

}
