package com.lti.training.day3.inheritance;

public enum LogLevel {
	
	INFO,WARN,ERROR;

}
