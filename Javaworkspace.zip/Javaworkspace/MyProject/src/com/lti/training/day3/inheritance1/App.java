package com.lti.training.day3.inheritance1;

public class App {
	public static void main(String[] args) {
		
	Book b1=new Book("Java Handbook",99,500,"A classic book on Java");
	Book b2=new Book("Java Unleashed",99,400,"A magic book on Java");
	
	Toy t1=new Toy("RC Car",99,2500,"RC Car","4-5");
	Toy t2=new Toy("Superhero",99,500,"Action figure","5+");
	
	double bill1 = b1.generateBill(40);
	System.out.println("The bill amount for ordering 40 copies of"+ b2.getName() +" is "+ bill1);
  }
}