package com.lti.training.day3.inheritance.assign2;

public class Player {

}
