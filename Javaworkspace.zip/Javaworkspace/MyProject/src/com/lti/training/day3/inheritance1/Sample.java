package com.lti.training.day3.inheritance1;

public class Sample {

	static int x=20;
	public static void main(String[] args) {
		 int x=10;
		System.out.println(x);

	}

}
