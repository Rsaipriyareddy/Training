package com.lti.training.day3.inheritance.assign2;

public class Schedule {

	private String gameName;
	private String teamName;
	public Schedule(String gameName, String teamName) {
		super();
		this.gameName = gameName;
		this.teamName = teamName;
	}
	
	
	
	

	
}