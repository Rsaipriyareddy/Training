package com.lti.training.day5;

import java.util.Random;

public class Random1 { 
	Random r = new Random();
	int i = r.nextInt(100) + 1;


}
