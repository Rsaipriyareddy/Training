package com.lti.training.day5;

public class BrainBench {

	class SuperClass {
		public void printIt() {
		System.out.println("SuperClass");
		}
		public void printIt(boolean print) {
		if (print) {
		System.out.println("Super-part 2");
		}
		else {
		printIt();
		System.out.println();
		}
		}
		}
		class SubClass extends SuperClass {
		public void printIt() {
		System.out.println("SubClass");
		}
		}
		public static class TestSub {
		public void main(String args[]) {
		SuperClass sc=new SubClass();
		sc.printIt();
		sc.printIt(false);
		}
		}
	
		}
	

