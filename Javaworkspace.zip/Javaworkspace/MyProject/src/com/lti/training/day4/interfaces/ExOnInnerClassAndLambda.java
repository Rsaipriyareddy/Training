package com.lti.training.day4.interfaces;

interface Printer{
	void print(String document);
}
class DotMatrixPrinter implements Printer {

	@Override
	public void print(String document) {
		System.out.println("Currently printing"+document);	
	}
}

public class ExOnInnerClassAndLambda {
	
	public static void main(String[]args) {
		//class A{
			
	//	}
		
		class DeskjetPrinter implements Printer{

			@Override
			public void print(String document) {
				System.out.println("Now printing"           +document);
             				
			}
			
		}
		Printer p=new DeskjetPrinter();
		p.print("abc.txt");
		
		
		
		//anonymous inner class
		Printer sp=new Printer() {
			
			@Override
			public void print(String document) {
				System.out.println("Now printing" +document);
            				
			}
		};
		sp.print("xyz.txt");
	}
  
}
