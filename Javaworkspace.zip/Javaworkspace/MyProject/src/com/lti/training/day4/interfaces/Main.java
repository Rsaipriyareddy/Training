package com.lti.training.day4.interfaces;

import com.lti.training.day4.Launcher;

public class Main {
	
	public static void main(String[]args) {
		Launcher launch=new Launcher();
		
		MyMobileApplication1 app1=new MyMobileApplication1();
		launch.launch(app1);
		
		MyMobileApplication2 app2=new MyMobileApplication2();
		launch.launch(app2);
		
		app1.version();
		
		//try displaying the count of running apps
		
		//to close all the running apps
		launch.closeAllRunningApps();
	}

}




