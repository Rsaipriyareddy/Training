package com.lti.training.day4.interfaces;

public class Stringham {
	
	public static void main(String[]args) {
		String s1="Java";
		String s2="Java";
		String s3=new String("Java");
		String s4=new String("Java");
		
		System.out.println(s1==s2);
		System.out.println(s3==s4);
		
		String s5="JAVA";
		String s6=s5.toLowerCase();
		System.out.println(s5==s6);
		
		
		String s7="hello";
		String s8="world";
		String s9="helloworld";
		String s10=(s7+s8).intern();
		System.out.println(s9==s10);
		
		String str="dfrgjfvdhfgidjfhiurklojlihjikhkdhkhoiuh56662356jirghrngrihyLJBGKHGIUHKJVIJNKVNB<KFBHJWS NJC:LFBJK FKJFKJHFK";
		String newstr="";
		
		System.out.println("-------------------------using concatination-------------------------------");

		
		long ns1=System.nanoTime();
		
		for(int i=0;i<str.length();i++)
			for(int j=0;j<=i;j++)
				newstr+=str.charAt(j);
		long ns2=System.nanoTime();
		System.out.println("result is"+newstr);
		System.out.println("Approx time taken:"+(ns2-ns1)+"nanoseconds");
		
		
		System.out.println("-------------------------using string buffer-------------------------------");
		StringBuffer strbuffer=new StringBuffer();
		ns1=System.nanoTime();
		for(int i=0;i<str.length();i++)
			for(int j=0;j<=i;j++)
				strbuffer.append(str.charAt(j));
		ns2=System.nanoTime();
		System.out.println("result is................................."+strbuffer);
		System.out.println("Approx time taken:"+(ns2-ns1)+"nanoseconds");
		
		
		
		System.out.println("-------------------------using string builder-------------------------------");
		StringBuilder strbuilder=new StringBuilder();
		ns1=System.nanoTime();
		for(int i=0;i<str.length();i++)
			for(int j=0;j<=i;j++)
				strbuffer.append(str.charAt(j));
		ns2=System.nanoTime();
		System.out.println("result is................................."+strbuilder);
		System.out.println("Approx time taken:"+(ns2-ns1)+"nanoseconds");
		
		
		
		

		
		
		
				
	}

}
