package com.lti.training.day4.interfaces;

/**
 * created for a mobile application
 * @author venkygoogle
 *
 */

public interface MobileApplication {
	
	String INFO="Developed by venkygoogle";
	
	public void start();
	public void pause();
	public void stop();
	
	
	//non abstract&static methods allowed from Java 8 onwards
	public default void version() {
		System.out.println(INFO+"Version is 1.0");
	}
	

}
