package com.lti.training.day4;

import com.lti.training.day4.interfaces.MobileApplication;

/**
 * inbuilt launcher
 * for launching mobile apps
 * @author venkygoogle
 *
 */
public class Launcher {
	
	private static TaskManager taskManager=new TaskManager();
	
	
	public void launch(MobileApplication mobileApp) {
		mobileApp.start();
	
		taskManager.inform(mobileApp);
		//mobileApp.pause();
		//mobileApp.stop();
		
	
	}
	
	public void closeAllRunningApps() {
		taskManager.clearAll();
	}
	

}
