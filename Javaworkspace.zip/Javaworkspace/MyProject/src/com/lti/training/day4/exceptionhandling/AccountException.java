package com.lti.training.day4.exceptionhandling;

public class AccountException extends Exception {
	public AccountException(String message) {
		super(message);
	}

}
