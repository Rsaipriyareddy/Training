package com.lti.training.day4.interfaces;

/**
 * My dummy mobile app
 * @author venky
 *
 */

public class MyMobileApplication2 implements MobileApplication  {
	
	

	@Override
	public void start() {
		System.out.println("My awesome MobileApplication2 started..");
		
	}

	@Override
	public void pause() {
		System.out.println("My awesome MobileApplication2 paused..");
		
	}

	@Override
	public void stop() {
		System.out.println("My awesome MobileApplication2 stopped..");
		
	}

}
