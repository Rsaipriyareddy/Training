package com.lti.training.day4;

import com.lti.training.day4.interfaces.MobileApplication;

/**
 * an inbuilt task manager
 * @author venkygoogle
 *
 */

public class TaskManager {
	
	private MobileApplication[] mobileApps;
	private int count;
	
	public TaskManager() {
		mobileApps=new MobileApplication[9999];
	}
	
	public void inform(MobileApplication mobileApp) {
		mobileApps[count++]=mobileApp;
	}
	
	public int mobileApps() {
		return count;
	}
	
	public void clearAll() {
		for(int i=0;i<count;i++)
		//for(MobileApplication app: mobileApps)
			mobileApps[i].stop();
	}

}
