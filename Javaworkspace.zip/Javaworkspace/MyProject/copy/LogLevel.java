package com.lti.training.day3.inheritance1.copy;

public enum LogLevel {
	
	INFO,WARN,ERROR;

}
