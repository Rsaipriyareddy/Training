package com.lti.training.day3.inheritance1.copy;

import java.time.LocalDateTime;

/**
 * A Simple CUSTOM LOGGER IMPLEMENTATION
 * @author Shaik Rafiq
 * @version 1.0
 *
 */
public abstract class Logger {
	
	public void log(String msg) {
		log(msg,LogLevel.INFO);
	}
	
	public void log(String msg,LogLevel level)
	{
		
	}
	
}
