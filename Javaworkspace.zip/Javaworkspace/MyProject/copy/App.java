package com.lti.training.day3.inheritance1.copy;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Testing our Logger
		
		//Logger l=new Logger();
		//Logger l=new FileLogger();//it creates object of FileLogger
		Logger l=LogFactory.  
		l.log("App Started Successfully\n");
		l.log("Some Message\n", LogLevel.INFO);
		l.log("Again Some Message\n", LogLevel.WARN);
		l.log("Some Critical Message", LogLevel.ERROR);
		
		l=new ConsoleLogger();//it creates object of ConsoleLogger
		l.log("ConsoleLogger");//it first checks for method signature in Logger class and implements or overrides the body in ConsoleLogger
	
	}
}
