package com.lti.training.day3.inheritance1.copy;

public class LogFactory {

	public static Logger getLoggerInstance() {
		return new ConsoleLogger();
	}
	
}
