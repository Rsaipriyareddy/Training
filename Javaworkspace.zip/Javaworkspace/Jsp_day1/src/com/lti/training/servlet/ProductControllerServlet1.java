package com.lti.training.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ProductControllerServlet1 extends HttpServlet {
	
   

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int pgsize=4;
		int currentPosition=1;
		String page=request.getParameter("page");
		if(page!=null) {
			if(page.equals("next"))
				currentPosition+=pgsize;
			else if(page.equals("prev"))
				currentPosition-=pgsize;
		}
		else
			currentPosition=1;
		Productd 
		List<Product> product=dao.fetch
		
		
	}

	
	

}
