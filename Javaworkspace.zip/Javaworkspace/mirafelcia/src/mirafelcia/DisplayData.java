package mirafelcia;

public class DisplayData {
	public static void main(String args[])
	{
		String[][] data={ {"p101","nokia","description","2000"},
				                 {"p102","samsung","description","2000"},
				                 {"p103","sony_ericson","description","2000"},
				                 {"p104","lg handset","description","2000"}};
	      String[] colname= {"id","name","description","price"};
	      String str,str1;
	      int  i,id_len,j=0,max=0,k,n=4,l;
	     for(j=0;j<colname.length;j++) {
	      for(i=0;i<n;i++) {
	    	  str=data[i][j];
	    	  id_len=str.length();
	    	  if(id_len>max) {
	    		  max=id_len;
	    	  }
	    	  
	      }
	     
	     
	      for(i=0;i<(max+3);i++)
	      {
	    	  System.out.print("-");
	    	
	    	  
	      }
	      System.out.print("|");
	    	
	  
	     }
	     System.out.println("\n");
	    	 
	    	 for(l=0;l<colname.length;l++) {
	    		 str1=colname[l];
	    		 System.out.print(" ");
	    		System.out.print(str1); 
	    		System.out.print("      ");
	    	 }
		    	
	    	 
	     
	     
	    	  }
}
	      

	      
	      
				                 
				                 
														
								


