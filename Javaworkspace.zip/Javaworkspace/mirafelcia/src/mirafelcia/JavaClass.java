package mirafelcia;

public class JavaClass {
	public static void main(String[ ] args)
	{
	String  c="हँसी ";
System.out.println(c);
}
}