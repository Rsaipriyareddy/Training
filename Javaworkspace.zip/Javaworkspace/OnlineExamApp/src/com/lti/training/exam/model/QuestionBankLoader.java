package com.lti.training.exam.model;

import java.util.ArrayList;
import java.util.List;

public class QuestionBankLoader {
	Option o1,o2,o3,o4;
	List<Option> opts;
	Question q;
	public List<Question> fetchQuestionsOnJava(){
		QuestionBank qb= new QuestionBank();
		qb.addNewSubject("Java");
		
		 q= new Question();
		q.setQuestion("What is a class?");
		List<Option> opts= new ArrayList<Option>();
		 o1=new Option();
		o1.setOption("class ia template for object");
		o1.setRightAnswer(true);
		 o2=new Option();
		o2.setOption("class is a instance of an object");
		o2.setRightAnswer(false);
		 o3=new Option();
		o3.setOption("class ia another name for object");
		o3.setRightAnswer(false);
		 o4=new Option();
		o4.setOption("all of above");
		o4.setRightAnswer(false);
		opts.add(o1);
		opts.add(o2);
		opts.add(o3);
		opts.add(o4);
		q.setOptions(opts);
		qb.addNewQuestion("Java", q);
		
		 q= new Question();
		q.setQuestion("What is a object");
		 opts= new ArrayList<Option>();
		 o1=new Option();
		o1.setOption("class ia template for obj");
		o1.setRightAnswer(false);
		 o2=new Option();
		o2.setOption("object is a instance of a class");
		o2.setRightAnswer(true);
		 o3=new Option();
		o3.setOption(" object is primite data type");
		o3.setRightAnswer(false);
		 o4=new Option();
		o4.setOption("none of above");
		o4.setRightAnswer(false);
		opts.add(o1);
		opts.add(o2);
		opts.add(o3);
		opts.add(o4);
		q.setOptions(opts);
		qb.addNewQuestion("Java", q);
	
		
		q= new Question();
		q.setQuestion("What is a ArrayList ");
		 opts= new ArrayList<Option>();
		 o1=new Option();
		o1.setOption("Array is a collection of data types");
		o1.setRightAnswer(true);
		 o2=new Option();
		o2.setOption("arrayList is a instance of a List");
		o2.setRightAnswer(false);
		 o3=new Option();
		o3.setOption(" ArrayList is primite data type");
		o3.setRightAnswer(false);
		 o4=new Option();
		o4.setOption("none of above");
		o4.setRightAnswer(false);
		opts.add(o1);
		opts.add(o2);
		opts.add(o3);
		opts.add(o4);
		q.setOptions(opts);
		qb.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("What is collections?");
		 opts= new ArrayList<Option>();
		 o1=new Option();
		o1.setOption("collection is a group of materials");
		o1.setRightAnswer(false);
		 o2=new Option();
		o2.setOption("collections  is a instance of a class");
		o2.setRightAnswer(false);
		 o3=new Option();
		o3.setOption(" The Collection in Java is a framework that provides an architecture to store and manipulate the group of objects");
		o3.setRightAnswer(true);
		 o4=new Option();
		o4.setOption("all of above");
		o4.setRightAnswer(false);
		opts.add(o1);
		opts.add(o2);
		opts.add(o3);
		opts.add(o4);
		q.setOptions(opts);
		qb.addNewQuestion("Java", q);
		
		return qb.getQuestionsFor("Java");
	
	}

}
