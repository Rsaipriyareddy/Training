package com.lti.prac;

import java.util.Random;

public class Exampless {
	Random r=new Random();
	int i = r.nextInt(100) + 1;

}
