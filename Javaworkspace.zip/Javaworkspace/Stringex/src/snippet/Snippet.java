package snippet;

public class Snippet {
	public static void main(String[] args) {
		p.setId(rs.getInt(1));
	}
}

