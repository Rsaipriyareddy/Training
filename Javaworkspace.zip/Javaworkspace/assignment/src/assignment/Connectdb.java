package assignment;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Connectdb {


	

	
	public static void main(String[] args) {
		Connection conn =null ;
		try {
			//loading jdbc driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//establish connection with the database
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="hr";
			String pass="hr";
			conn =DriverManager.getConnection(url,user,pass);
			System.out.println("Connected Succesfully");
		}
		catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println("JDBC driver not found");
		}
		catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			try { conn.close(); } catch(Exception e) {}
		}
		
	}
	}


