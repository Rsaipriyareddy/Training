package assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class EmployeeDao {
	public void add(Employee employee) {
		Connection conn = null;
		PreparedStatement stmt = null; 
	 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
					
			String sql = "insert into Employee values(?,?,?,?)";
			stmt = conn.prepareStatement(sql);
			
			
			stmt.setInt(1, employee.getNo());
			stmt.setString(2, employee.getName());
			stmt.setInt(3, employee.getdno());
			stmt.setDouble(4, employee.getSalary());
			stmt.executeUpdate();
			
		}
		catch (ClassNotFoundException  e) {
			// TODO: handle exception
			System.out.println("JDBC driver not found");
		}catch(SQLException e) {
			// TODO: handle exception
		
		}
		finally {
			try {
				conn.close();
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		
	}

}
	public List<Employee> fetchAll() {
		Connection conn = null; // manages the connection  between the app and db
		PreparedStatement stmt = null; //helps us to execute SQL statements 
		ResultSet rs = null; //helps us to fetch the result of a select query
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","hr","hr");
					
			String sql = "select * from Employee ";
			stmt = conn.prepareStatement(sql);
			//stmt.setInt(1, 10);
			rs= stmt.executeQuery();
			
			List<Employee> employees = new ArrayList<Employee>();
			while(rs.next()) { //for each row
				Employee e= new Employee();
				e.setdNo(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setdNo(rs.getInt(3));
				e.setSalary(rs.getInt(4));
				employees.add(e);
				
			}
			return  employees;
		}
			
			
			
		
		catch (ClassNotFoundException  e) {
			// TODO: handle exception
			System.out.println("JDBC driver not found");
		}catch(SQLException e) {
			// TODO: handle exception
		
		}
		finally {
			try {
				conn.close();
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			return null ;
		}
	}
	
	
}
