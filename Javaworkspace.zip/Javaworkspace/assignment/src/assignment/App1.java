package assignment;

import java.util.List;
import java.util.Scanner;



public class App1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDao dao= new EmployeeDao();
		
		
		Employee e1=new Employee();
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter the employee no");
		e1.setNo(sc.nextInt());
		
		System.out.println("Enter the employee name");
		e1.setName(sc.next());
		
		System.out.println("Enter the employee department no");
		e1.setdNo(sc.nextInt());
		
		System.out.println("Enter the employee salary");
		e1.setSalary(sc.nextDouble());
		
		dao.add(e1);
		
		
		
		
	/*	e1.setNo(1);
		e1.setName("Siddhant");
		e1.setdNo(1);
		e1.setSalary(99);
		
		dao.add(e1);
		System.out.println("Data Inserted"); 
		*/
		
		List<Employee> employee = dao.fetchAll();
		for(Employee e:employee) {
			System.out.println();
		}
		try {
		
		for (Employee e : employee) {
			System.out.println("No = " + e.getNo());
			System.out.println("Name = " + e.getName());
			System.out.println("Department no = " + e.getdno());
			System.out.println("Salary = " + e.getSalary());
		}
		}
		catch (NullPointerException e ) {
			// TODO: handle exception
		
		}

	} 

}



