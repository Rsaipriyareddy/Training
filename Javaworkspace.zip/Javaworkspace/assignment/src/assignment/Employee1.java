package assignment;

public class Employee1 {

}
