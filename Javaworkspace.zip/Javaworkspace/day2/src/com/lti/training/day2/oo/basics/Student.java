package com.lti.training.day2.oo.basics;

public class Student {

		String name;
		String college;
		String doj;
	
	
}
