package com.lti.training.day2.oo.basics;

public class Employee {
	
	private int empno;
	private String name;
	private String dateOfTheJoining;
	private double salary;
	
	//has a relationship
	//association
	//one to one associaiton
	private Passport passport;
	
	private AadharCard aadharCard;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateOfTheJoining() {
		return dateOfTheJoining;
	}

	public void setDateOfTheJoining(String dateOfTheJoining) {
		this.dateOfTheJoining = dateOfTheJoining;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Passport getPassport() {
		return passport;
	}

	public void setPassport(Passport passport) {
		this.passport = passport;
	}

	public AadharCard getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(AadharCard aadharCard) {
		this.aadharCard = aadharCard;
	}
	
	
	public void displayInfo( ) {
		 System.out.println(empno);
	     System.out.println(name);
	     System.out.println(dateOfTheJoining);
	     System.out.println(salary);
	     System.out.println();
	     
	     System.out.println(passport.getPassportNo());
	     System.out.println(passport.getNameOfThePerson());
	     System.out.println(passport.getIssueDate());
	     System.out.println(passport.getExpiryDate());
	   
	     System.out.println(aadharCard.getAadharNo());
	     System.out.println(aadharCard.getName());
	     System.out.println(aadharCard.getAddress());
	}
	
}
