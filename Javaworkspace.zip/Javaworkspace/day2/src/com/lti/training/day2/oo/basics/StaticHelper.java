package com.lti.training.day2.oo.basics;

public class StaticHelper {
	static String name="";

}
