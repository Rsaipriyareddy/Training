package com.lti.training.day2.oo.basics;


public class App {

	public static void main(String[] args) {
		//creating object of Student class
		Student student1 = new Student();
		student1.name="ABC";
		student1.college="VIT";
	     student1.doj="1 june ";
	     
	     
	     Passport passport1=new Passport();
	     passport1.setPassportNo("P1234");
	     passport1.setNameOfThePerson("Tejas");
	     passport1.setIssueDate("10/3/19");
	     passport1.setExpiryDate("10/2/5");
	     
	     System.out.println("=====Passport details=====");
	     
	     
	     System.out.println(passport1.getPassportNo());
	     System.out.println(passport1.getNameOfThePerson());
	     System.out.println(passport1.getIssueDate());
	     System.out.println(passport1.getExpiryDate());
	     
	     
	     
	     
	     
	     
	   AadharCard ac= new AadharCard(12345,"Tejas","Mumbai");
	   
	   System.out.println("====Aadharcard Details====");
	     
	     
	     System.out.println(ac.getAadharNo());
	     System.out.println(ac.getName());
	     System.out.println(ac.getAddress());
	     

	     
	    
	      //System.out.println(student1.name + "  " +student1.college + " "+ student1.doj);
	     
	}
}
