package com.lti.training.day2.oo.basics;

public class Calculator {

	
	public void add(int x,int y) {
		System.out.println(x+y);
		
	}
	public void sub(int x,int y) {
		System.out.println(x-y);
		
	}
	
	public static void div(int x,int y) {
     System.out.println(x/y);
	}
	
	public static void mul(int x,int y) {
		System.out.println(x*y);
	}
	
}




