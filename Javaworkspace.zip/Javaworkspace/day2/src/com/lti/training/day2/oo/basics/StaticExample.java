package com.lti.training.day2.oo.basics;

public class StaticExample {

	public static void main(String args[]) {
	/*StaticHelper.name="Tejas";
	
	System.out.println(StaticHelper.name);
	StaticHelper.name="Siddhant";
	System.out.println(StaticHelper.name);
	StaticHelper.name="Raghav";
	System.out.println(StaticHelper.name);*/
		
		StaticHelper tejas = new StaticHelper();
		tejas.name="Tejas";
		StaticHelper raghav = new StaticHelper();
		raghav.name="Raghav";
		StaticHelper siddhant = new StaticHelper();
		siddhant.name="Siddhant";
		
		System.out.println(tejas.name);
		System.out.println(raghav.name);
		System.out.println(siddhant.name);
	}
}
