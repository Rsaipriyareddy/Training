package com.lti.training.day2.oo.basics;

public class Practice {
	public static void main(String[] args) {
		
		Employee e1=new Employee();
		e1.setEmpno(101);
		e1.setName("Siddhant");
		e1.setDateOfTheJoining("10-05-10");
		e1.setSalary(30000);
		
		Passport p1=new Passport();
		p1.setPassportNo("5628");
		p1.setNameOfThePerson("tejas");
		p1.setIssueDate("10/10/2010");
		p1.setExpiryDate("10/10/2019");
		e1.setPassport(p1);
		
		AadharCard a1=new AadharCard();
		a1.setAadharNo(12345);
		a1.setName("Siddhant");
		a1.setAddress("u-34/34");
		e1.setAadharCard(a1);
	
		System.out.println("Passportnono"+ e1.getPassport().getPassportNo());
		
		 /*System.out.println(e1.getEmpno());
	     System.out.println(e1.getName());
	     System.out.println(e1.getDateOfTheJoining());
	     System.out.println(e1.getSalary());
	     System.out.println();
	     
	     System.out.println(p1.getPassportNo());
	     System.out.println(p1.getNameOfThePerson());
	     System.out.println(p1.getIssueDate());
	     System.out.println(p1.getExpiryDate());
	   
	     System.out.println(a1.getAadharNo());
	     System.out.println(a1.getName());
	     System.out.println(a1.getAddress());*/
	     
	    e1.displayInfo();
	    
	     
	}
	     
}
