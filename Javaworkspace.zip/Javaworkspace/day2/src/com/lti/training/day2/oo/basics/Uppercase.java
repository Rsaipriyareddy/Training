package com.lti.training.day2.oo.basics;
//write a java program which will for a given integer 
//for ex:
//int x=65
/*will display the binary ,octal and hexadecimal representation  of the above number
 * java.lang.Integer classs will help you in getting the required output
 */
		
public class Uppercase {
	public static void main(String[] args) {
		int l=65;
		System.out.println(Integer.toBinaryString(l));
		System.out.println(Integer.toHexString(l));
		System.out.println(Integer.toOctalString(l));
	}

}
