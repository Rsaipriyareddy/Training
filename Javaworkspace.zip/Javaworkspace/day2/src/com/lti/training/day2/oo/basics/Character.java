package com.lti.training.day2.oo.basics;

public class Character {
	public static void main(String[] args) {
		String str="what is your number";
		char ch=str.charAt(8);		
		System.out.println(ch);
	}

}
