package com.lti.training.day2.oo.basics;

public class Calculatorapp {
	public static void main(String[] args) {
		Calculator cal= new Calculator();
		cal.add(5,6);
		cal.sub(10,5);
		Calculator.div(10, 5);
		Calculator.mul(10,5);
	}
}
