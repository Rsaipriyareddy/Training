package com.lti.training.day2.oo.basics;

public class Object {

	public static void main(String args[])
	{
		Address address=new Address();
		address.setCity("Gurugram");
		address.setState("haryana");
		address.setPincode(122002);
		
		Customer customer=new Customer();
				customer.setName("Sid");
				customer.setEmail("sidgamil");
				customer.setAddress(address);
				
			customer.disp();
	}
		
}
