package com.lti.day6;

import java.util.HashMap;
import java.util.Map;

public class MapEg {
	public static void main(String[] args) {
		
	
	Map<String, String> map1= new HashMap<String, String>();
	map1.put("23.45.66", "uthra");
	map1.put("23.45.11", "uthraa");
	map1.put("23.45.22", "swathi");
	map1.put("23.45.35", "uthu");
	String user=map1.get("23.45.11");
	System.out.println(user);
	

}
}