package com.lti.day6;

import java.util.ArrayList;
import java.util.List;

public class UserManager {
	
	private List<User> lu;
	public UserManager() {
		// TODO Auto-generated constructor stub
		lu=new ArrayList<User>();
		lu.add(new User("ugu","111",false));
		lu.add(new User("dinesh","222",true));
		lu.add(new User("hgugu","231",false));
		
	}
	public boolean isValid(String username,String password) {
	
		for(User us:lu) {
		String name=username;
			if(name.equals(us.getUsername())) 
				if(password.equals(us.getPassword())&&us.isActive()) 
				return true;
				
				
		}
			return false;
		
		
		
	}
/* static void main(String[] args) {
		UserManager mgr=new UserManager();
		boolean isValid=mgr.isValid("swathi","222");
		System.out.println(isValid);
		UserManager m=new UserManager();
		 isValid=m.isValid("aaaaa", "678");
		
		
		System.out.println(isValid);
	}*/
	

}
