package com.lti.day6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserManager2 {
	
	private Map<String, String> lu;
	public UserManager2() {
		// TODO Auto-generated constructor stub
		lu = new HashMap<String, String>();
		lu.put("uthra","111");
		lu.put("swathi","222");
		lu.put("uthu","231");
		
	}
	public boolean isValid(String username,String password) {
	
		for(Map.Entry<String, String> us:lu.entrySet()) {
		String name=username;
			if(name.equals(us.getKey())) 
				if(password.equals(us.getValue())) 
				return true;
				
				
		}
			return false;
		}
	//public boolean isValid(String username,String password) {
	//	if(username.equals(lu.getKe)
//	}
	
	public static void main(String[] args) {
		UserManager2 mgr=new UserManager2();
		boolean isValid=mgr.isValid("swathi","222");
		System.out.println(isValid);
		UserManager2 m=new UserManager2();
		 isValid=m.isValid("aaaaa", "678");
		
		
		System.out.println(isValid);
	}
	

}
