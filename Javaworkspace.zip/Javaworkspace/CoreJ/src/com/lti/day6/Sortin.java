package com.lti.day6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

public class Sortin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     List<Integer> list1 = new ArrayList<Integer>	();
    list1.add(10);
    list1.add(50);
    list1.add(30);
    list1.add(20);
    list1.add(40);
    
    
System.out.println("before sorting");
	for(Integer no : list1)
	  System.out.println(no);	

	Collections.sort(list1);
	System.out.println("after sorting");
	
	for(Integer ae : list1)
		  System.out.println(ae);	
	
	List<Person> lp = new ArrayList<Person>();
	lp.add(new  Person(15,"uthra"));
	lp.add(new  Person(11,"athr"));
	lp.add(new  Person(14,"cth"));
	lp.add(new  Person(13,"bt"));
	
	Comparator<Person> c=new Comparator<Person>() {
		
		@Override
		public int compare(Person p1, Person p2) {
			// TODO Auto-generated method stub
			
			return -p1.getName().compareTo(p2.getName());
		}
	};
Comparator<Person> d=new Comparator<Person>() {
		
		@Override
		public int compare(Person p1, Person p2) {
			// TODO Auto-generated method stub
			
			return -(p1.getAge() - p2.getAge());
		}
	};
	
	//Comparator<Person>  e= (p1,p2) - > {p2.getAge()  -  p1.getAge()};
	Collections.sort(lp,d);
	for(Person a:lp) {
		System.out.println(a.name+a.age);
	}
	}

}
