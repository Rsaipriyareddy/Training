package com.lti.day6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EgList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list1=new ArrayList<String>();
		list1.add("a");
		list1.add("b");
		list1.add("c");
		list1.add("a");
		list1.add("d");
		// remove method
		list1.remove(1);
		List<String> list2=new ArrayList<String>();
        list2.add("hi");
        list2.add("hello");
        // add all method
        list1.addAll(list2);
        //set method
		list1.set(1, "abc");
       //adding and shifting method
		list1.add(5,"see");
		//sublist method
		System.out.println(list1.subList(2,6));
		//indexOf method
		int c= list1.indexOf("a");
		System.out.println(c);
		//last indexOf method
		int d=list1.lastIndexOf("a");
		System.out.println(d);
		//clear method
      //  list1.clear();
		for(int i=0;i<list1.size();i++) {
			String str=(String) list1.get(i);
			System.out.println(str);
		}
		 Person p=new Person(101, "Ss");
		    Person p1=new Person(102,"aa");
		    Person p2=new Person(103,"sss");
		    p.setAge(1);
		    p.setName("uthra");
		    p1.setAge(2);
		    p1.setName("abc");
		    p2.setAge(43);
		    p2.setName("uthraa");
		List<Person> listp=new ArrayList<Person>();
		listp.add(p);
		listp.add(p1);
		listp.add(p2);
		Iterator itr=listp.iterator();  
		   System.out.println("----- iterator displaying person class details------");
		  while(itr.hasNext()){  
		    Person po=(Person)itr.next();  
		    System.out.println(po.age+" "+po.name+" ");  
		  }  
		  System.out.println("-----for eACH using lambda LOOP");
		  listp.forEach(po ->System.out.println(po.age+po.name));
		  System.out.println("-----for each loop");
		  
		  for(Person pfe:listp) {
			  System.out.println(pfe.name+pfe.age);
		  }
		
		
		
		
		
		
		
	}

}
