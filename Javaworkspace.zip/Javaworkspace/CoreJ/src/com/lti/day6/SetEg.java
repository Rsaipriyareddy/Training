package com.lti.day6;

import java.util.HashSet;
import java.util.Set;

public class SetEg {
	
	public static void main(String[] args) {
		
		Set<String> set1=new HashSet<String>();
		set1.add("a");
		set1.add("b");
		set1.add("c");
		set1.add("a");
		set1.add("d");
		for(String str : set1)
			System.out.println(str);
		
		 Person p=new Person(101, "Ss");
		    Person p1=new Person(102,"aa");
		    Person p2=new Person(103,"sss");
		    p.setAge(1);
		    p.setName("uthra");
		    p1.setAge(2);
		    p1.setName("abc");
		    p2.setAge(1);
		    p2.setName("uthra");
		    
		    Set<Person> po=new HashSet<Person>();
		   po.add(p);
		   po.add(p1);
		   po.add(p2);
		   for(Person pfe:po) {
				  System.out.println(pfe.name+pfe.age);
			  }
		   
		
	
}
}
