package day7java;

import java.util.List;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProductDao dao= new ProductDao();
		
		
		/*Product p=new Product();
		p.setId(1);
		p.setName("Nokia 600");
		p.setPrice(5000);
		p.setQuantity(99);
		
		dao.add(p);
		System.out.println("Data Inserted"); */
		try {
		List<Product> product = dao.fetchAll();
		for (Product p : product) {
			System.out.println("ID = " + p.getId());
			System.out.println("Name = " + p.getName());
			System.out.println("Price = " + p.getPrice());
			System.out.println("Quantity = " + p.getQuantity());
		}
		}
		catch (NullPointerException e) {
			// TODO: handle exception
		}
	
	}

}
